from django.urls import path
from drf_spectacular.views import SpectacularAPIView, SpectacularSwaggerView
# from .views import UserAPIView, ObtainTokenAPIView, CreateUserAPIView
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    # Swagger documentation endpoints
    path('api/schema/', SpectacularAPIView.as_view(), name='schema'),
    path('api/docs/', SpectacularSwaggerView.as_view(url_name='schema'), name='docs'),
    

    # API endpoints
    # path('api/users/', UserAPIView.as_view(), name='user-list'),
    # path('api/users/<int:pk>/', UserAPIView.as_view(), name='user-detail'),
    # path('api/token/', ObtainTokenAPIView.as_view(), name='token'),
    # path('api/register/', CreateUserAPIView.as_view(), name='register'),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
