# from drf_spectacular.utils import (
#     extend_schema_view,
#     extend_schema,
#     OpenApiParameter,
#     OpenApiTypes,
# )
# from rest_framework import generics, authentication, permissions
# from rest_framework.authtoken.views import ObtainAuthToken
# from rest_framework.settings import api_settings
# from .serializers import UserSerializer, AuthTokenSerializer
# from .models import User


# @extend_schema_view(
#     create=extend_schema(
#         description='Create a new user in the system',
#         responses={201: UserSerializer}
#     ),
#     update=extend_schema(
#         description='Update an existing user',
#         responses={200: UserSerializer}
#     ),
#     delete=extend_schema(
#         description='Delete an existing user',
#         responses={204: 'No Content'}
#     ),
# )
# class UserAPIView(generics.RetrieveUpdateDestroyAPIView):
#     queryset = User.objects.all()
#     serializer_class = UserSerializer
#     authentication_classes = [authentication.TokenAuthentication]
#     permission_classes = [permissions.IsAuthenticated]

#     def get_object(self):
#         return self.request.user


# @extend_schema_view(
#     create=extend_schema(
#         description='Create a new authentication token',
#         responses={200: AuthTokenSerializer}
#     )
# )
# class ObtainTokenAPIView(ObtainAuthToken):
#     serializer_class = AuthTokenSerializer
#     renderer_classes = api_settings.DEFAULT_RENDERER_CLASSES


# @extend_schema_view(
#     create=extend_schema(
#         description='Create a new user',
#         responses={201: UserSerializer}
#     ),
# )
# class CreateUserAPIView(generics.CreateAPIView):
#     serializer_class = UserSerializer
